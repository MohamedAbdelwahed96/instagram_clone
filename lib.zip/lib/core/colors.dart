import 'package:flutter/material.dart';

class ColorsManager {
  static const Color enabledButton = Color.fromRGBO(0, 163, 255, 1);
  static const Color disabledButton = Color.fromRGBO(0, 163, 255, 0.5);
}